/* ИРНР — учебный статический портал.
   Новости и документы редактируются в массивах ниже.
   GitHub Pages не поддерживает серверную авторизацию и серверную обработку форм. */
"use strict";

const newsItems = [
  {
    id: "portal-launch",
    date: "2026-10-15",
    category: "Объявление",
    title: "Открыт обновлённый информационный портал ИРНР",
    summary: "Демонстрационная главная страница объединяет новости, документы и цифровые сервисы проекта.",
    body: "В рамках учебного проекта подготовлен единый портал с разделами новостей, учреждений, документов и сервисов для граждан. Макет предназначен для демонстрации структуры сайта и может быть изменён под задачи проекта.\n\nЭто вымышленная публикация. Она не является официальным сообщением реально существующего государственного органа."
  },
  {
    id: "diplomacy",
    date: "2026-10-12",
    category: "Дипломатия",
    title: "Опубликован проект гуманитарной инициативы",
    summary: "В архив добавлен пример дипломатического документа для обсуждения.",
    body: "В архиве размещён демонстрационный проект документа о гуманитарном сотрудничестве. Текст предназначен для редактирования и обсуждения в рамках вымышленной ролевой или учебной инициативы.\n\nДокумент не создаёт юридических обязательств и не является официальной дипломатической нотой."
  },
  {
    id: "public-docs",
    date: "2026-10-08",
    category: "Документы",
    title: "Архив документов получил тематические категории",
    summary: "Материалы теперь можно искать по названию и типу документа.",
    body: "В демонстрационном архиве предусмотрены категории основного закона, дипломатии и административных материалов. Поиск и фильтрация работают в браузере без серверного подключения."
  },
  {
    id: "citizen-services",
    date: "2026-10-02",
    category: "Сервисы",
    title: "Подготовлен макет цифровых обращений",
    summary: "Форма позволяет создавать локальные тестовые записи и просматривать их в профиле.",
    body: "Форма обращения — демонстрационная. Записи сохраняются только в локальном хранилище текущего браузера. Чтобы принимать реальные обращения, проекту понадобится защищённый сервер и политика обработки данных."
  }
];

const documents = [
  {
    id: "constitution",
    title: "Конституция ИРНР — демонстрационный макет",
    category: "Основной закон",
    date: "15.10.2026",
    number: "ОСНОВНОЙ ЗАКОН · ПРОЕКТ",
    description: "Структура разделов основного закона вымышленного проекта.",
    body: "КОНСТИТУЦИЯ ИРНР\nДЕМОНСТРАЦИОННЫЙ МАКЕТ\n\nПреамбула\nНастоящий учебный текст демонстрирует оформление основного закона в рамках вымышленного проекта.\n\nРаздел I. Общие положения\n1. Наименование и символика проекта определяются отдельными материалами.\n2. Все положения требуют самостоятельной разработки и согласования участниками проекта.\n\nРаздел II. Права и обязанности\nЭтот раздел оставлен для заполнения автором проекта.\n\nПримечание: это не действующий нормативный правовой акт."
  },
  {
    id: "foreign-note",
    title: "Шаблон дипломатической ноты",
    category: "Дипломатия",
    date: "15.10.2026",
    number: "МИД · ШАБЛОН",
    description: "Заготовка для дипломатических обращений и инициатив.",
    body: "ДИПЛОМАТИЧЕСКАЯ НОТА\n\nИсх. № ____/____\nДата: ______________\nМесто составления: ______________\nАдресат: ______________\nОтправитель: ______________\n\nТема: ______________________________\n\nТекст обращения:\n[Вставьте содержание документа. Проверьте имена, даты, формулировки и статус документа.]\n\nС уважением,\n[Должность]\n[Имя и фамилия]\n\nПримечание: шаблон для вымышленного проекта."
  },
  {
    id: "administrative-rule",
    title: "Положение о публикации материалов портала",
    category: "Административные",
    date: "08.10.2026",
    number: "АДМИНИСТРАТИВНЫЙ ДОКУМЕНТ · ПРИМЕР",
    description: "Пример правил оформления и размещения публикаций.",
    body: "ПОЛОЖЕНИЕ О ПУБЛИКАЦИИ МАТЕРИАЛОВ\n\n1. Материалы должны иметь заголовок, дату и категорию.\n2. Автор должен проверять корректность текста и ссылок.\n3. Публикации вымышленного проекта должны быть обозначены соответствующим образом.\n4. Не размещайте персональные данные без законного основания и согласия.\n\nЭтот текст является демонстрационным примером."
  },
  {
    id: "public-appeals",
    title: "Порядок обработки обращений — проект",
    category: "Административные",
    date: "02.10.2026",
    number: "ПРОЕКТ",
    description: "Описание демонстрационного процесса обработки обращений.",
    body: "ПОРЯДОК ОБРАБОТКИ ОБРАЩЕНИЙ — ПРОЕКТ\n\n1. В тестовой версии обращение сохраняется в браузере пользователя.\n2. Оно не передаётся администрации или на сервер.\n3. Для настоящего сервиса необходимо реализовать серверную часть, защиту от спама, контроль доступа, сроки хранения и правила обработки данных.\n\nДокумент носит информационный характер."
  }
];

// Условные курсы: базовое значение каждой валюты выражено в игровых единицах.
// 1 ИР = 2.5 КР; 1 ИР = 0.5 ТЛ. Значения можно изменить.
const currencyRates = { IR: 1, CR: 0.4, TK: 2 };
const currencyNames = { IR: "ИР", CR: "КР", TK: "ТЛ" };
const storageKeys = { theme: "irnr-theme", profile: "irnr-profile", requests: "irnr-requests" };

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const escapeHTML = (value) => String(value).replace(/[&<>"']/g, char => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[char]));

function formatDate(dateString) {
  const date = new Date(`${dateString}T12:00:00`);
  return new Intl.DateTimeFormat("ru-RU", { day: "2-digit", month: "long", year: "numeric" }).format(date);
}
function getShortDate(dateString) {
  const date = new Date(`${dateString}T12:00:00`);
  return { day: new Intl.DateTimeFormat("ru-RU", { day: "2-digit" }).format(date), month: new Intl.DateTimeFormat("ru-RU", { month: "short" }).format(date).replace(".", "") };
}
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 2600);
}
function openDialog(id) {
  const dialog = document.getElementById(id);
  if (dialog && typeof dialog.showModal === "function") dialog.showModal();
}
function getRequests() {
  try { return JSON.parse(localStorage.getItem(storageKeys.requests) || "[]"); }
  catch { return []; }
}
function saveRequests(items) {
  localStorage.setItem(storageKeys.requests, JSON.stringify(items));
}
function getProfile() {
  try { return JSON.parse(localStorage.getItem(storageKeys.profile) || "null"); }
  catch { return null; }
}

function renderNews() {
  const sorted = [...newsItems].sort((a, b) => b.date.localeCompare(a.date));
  const featured = sorted[0];
  $("#featuredNews").innerHTML = `
    <div class="news-meta"><span class="news-tag">${escapeHTML(featured.category)}</span><span>${formatDate(featured.date)}</span></div>
    <h3>${escapeHTML(featured.title)}</h3><p>${escapeHTML(featured.summary)}</p>
    <button type="button" data-article="${escapeHTML(featured.id)}">Читать публикацию →</button>`;
  $("#news-list").innerHTML = sorted.slice(1).map(item => {
    const short = getShortDate(item.date);
    return `<article class="news-item">
      <div class="news-date-box"><strong>${short.day}</strong><small>${escapeHTML(short.month)}</small></div>
      <div><span class="news-tag">${escapeHTML(item.category)}</span><h3><button type="button" data-article="${escapeHTML(item.id)}">${escapeHTML(item.title)}</button></h3><p>${escapeHTML(item.summary)}</p></div>
    </article>`;
  }).join("");
}
function openArticle(id) {
  const item = newsItems.find(entry => entry.id === id);
  if (!item) return;
  $("#articleContent").innerHTML = `<span class="eyebrow">${escapeHTML(item.category)} · ${formatDate(item.date)}</span><h2>${escapeHTML(item.title)}</h2><p class="article-body">${escapeHTML(item.body)}</p>`;
  openDialog("articleModal");
}
function renderDocuments() {
  const query = ($("#documentSearch").value || "").trim().toLocaleLowerCase("ru");
  const category = $("#documentCategory").value;
  const filtered = documents.filter(doc => (category === "all" || doc.category === category) &&
    `${doc.title} ${doc.description} ${doc.category}`.toLocaleLowerCase("ru").includes(query));
  $("#documentList").innerHTML = filtered.length ? filtered.map(doc => `
    <article class="document-row">
      <span class="doc-icon" aria-hidden="true">▤</span>
      <div class="doc-copy"><h3>${escapeHTML(doc.title)}</h3><p>${escapeHTML(doc.description)} · ${escapeHTML(doc.date)}</p><span class="doc-category">${escapeHTML(doc.category)} · ${escapeHTML(doc.number)}</span></div>
      <button type="button" data-document="${escapeHTML(doc.id)}">Открыть</button>
    </article>`).join("") : `<div class="empty-state">По вашему запросу ничего не найдено.</div>`;
}
function openDocument(id) {
  const doc = documents.find(entry => entry.id === id);
  if (!doc) return;
  $("#documentContent").innerHTML = `<span class="eyebrow">${escapeHTML(doc.category)} · ${escapeHTML(doc.date)}</span><h2>${escapeHTML(doc.title)}</h2><p class="article-body">${escapeHTML(doc.body)}</p><button type="button" class="button button-outline" id="copyDocument">Копировать текст</button>`;
  $("#documentModal").dataset.documentId = id;
  openDialog("documentModal");
}
function updateTheme(theme) {
  document.documentElement.dataset.theme = theme;
  $("#themeToggle").textContent = theme === "dark" ? "☀" : "☾";
  $("#themeToggle").setAttribute("aria-label", theme === "dark" ? "Включить светлую тему" : "Включить тёмную тему");
}
function updateAccountUI() {
  const profile = getProfile();
  $("#accountButton").textContent = profile?.name ? profile.name : "Личный кабинет";
  $("#accountTitle").textContent = profile?.name ? `Здравствуйте, ${profile.name}` : "Демо-профиль";
  $("#profileName").value = profile?.name || "";
  $("#profileId").value = profile?.id || "";
  const requests = getRequests();
  $("#myRequests").innerHTML = requests.length ? requests.slice().reverse().map(request => `
    <div class="request-entry"><strong>${escapeHTML(request.topic)}</strong>${escapeHTML(request.message)}<small>${escapeHTML(request.date)} · Статус: ${escapeHTML(request.status)}</small></div>`).join("") : `<p class="small-note">Пока нет сохранённых обращений.</p>`;
}
function updateCurrency() {
  const amount = Number($("#currencyAmount").value);
  const from = $("#currencyFrom").value;
  const to = $("#currencyTo").value;
  if (!Number.isFinite(amount) || amount < 0) {
    $("#currencyResult").textContent = "Введите корректную сумму";
    return;
  }
  const result = amount * currencyRates[from] / currencyRates[to];
  $("#currencyResult").textContent = `${new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 2, minimumFractionDigits: 2 }).format(result)} ${currencyNames[to]}`;
}

document.addEventListener("click", async event => {
  const openButton = event.target.closest("[data-open-modal]");
  if (openButton) openDialog(openButton.dataset.openModal);
  const articleButton = event.target.closest("[data-article]");
  if (articleButton) openArticle(articleButton.dataset.article);
  const docButton = event.target.closest("[data-document]");
  if (docButton) openDocument(docButton.dataset.document);
  if (event.target.closest("#copyDocument")) {
    const doc = documents.find(entry => entry.id === $("#documentModal").dataset.documentId);
    if (!doc) return;
    try {
      await navigator.clipboard.writeText(doc.body);
      showToast("Текст документа скопирован");
    } catch {
      showToast("Копирование недоступно в этом браузере");
    }
  }
});

$("#themeToggle").addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  updateTheme(next);
  localStorage.setItem(storageKeys.theme, next);
});
$("#menuToggle").addEventListener("click", () => {
  const open = $("#mainNav").classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(open));
  $("#menuToggle").textContent = open ? "×" : "☰";
});
$$(".main-nav a").forEach(link => link.addEventListener("click", () => {
  $("#mainNav").classList.remove("open");
  $("#menuToggle").setAttribute("aria-expanded", "false");
  $("#menuToggle").textContent = "☰";
}));
$("#documentSearch").addEventListener("input", renderDocuments);
$("#documentCategory").addEventListener("change", renderDocuments);
["currencyAmount", "currencyFrom", "currencyTo"].forEach(id => $(`#${id}`).addEventListener("input", updateCurrency));
$("#swapCurrency").addEventListener("click", () => {
  const from = $("#currencyFrom"), to = $("#currencyTo");
  [from.value, to.value] = [to.value, from.value];
  updateCurrency();
});
$("#accountForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = $("#profileName").value.trim();
  const id = $("#profileId").value.trim();
  if (!name) return;
  localStorage.setItem(storageKeys.profile, JSON.stringify({ name, id }));
  updateAccountUI();
  showToast("Демо-профиль сохранён в этом браузере");
});
$("#clearProfile").addEventListener("click", () => {
  localStorage.removeItem(storageKeys.profile);
  updateAccountUI();
  showToast("Локальный профиль очищен");
});
$("#requestForm").addEventListener("submit", event => {
  event.preventDefault();
  const topic = $("#requestTopic").value;
  const message = $("#requestMessage").value.trim();
  if (!message) return;
  const items = getRequests();
  items.push({
    id: `REQ-${Date.now().toString(36).toUpperCase()}`,
    topic,
    message,
    date: new Date().toLocaleString("ru-RU"),
    status: "Сохранено локально"
  });
  saveRequests(items);
  $("#requestMessage").value = "";
  $("#requestFeedback").textContent = "Обращение сохранено только в этом браузере. Оно не отправлено на сервер.";
  updateAccountUI();
  showToast("Демо-обращение сохранено");
});
$$("dialog").forEach(dialog => dialog.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
}));

const savedTheme = localStorage.getItem(storageKeys.theme);
updateTheme(savedTheme === "dark" ? "dark" : "light");
renderNews();
renderDocuments();
updateCurrency();
updateAccountUI();
$("#year").textContent = new Date().getFullYear();
